<?php
require "navbarHome.php";
require "index.html"
?>


# import tensorflow as tf

# # Load the model
# model = tf.keras.models.load_model('plant_disease_model.h5')

# # Save the model (overwriting the existing file)
# model.save('plant_disease_model.keras')


#  IMP 

# import tensorflow as tf

# model = tf.keras.models.load_model('plant_disease_model.keras')








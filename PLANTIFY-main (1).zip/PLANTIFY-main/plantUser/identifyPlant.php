<?php
require "navbarPlant.php";
require "../identifyPlant.html";
?>